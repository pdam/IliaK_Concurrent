

ENVIRONMENT = "QA Environment"
QA_URL = "app.qa.intraxinc.com"
our_db=("JV_QA")

AUPAIRROOM = QA_URL + "/apr-qa1"
HCR = QA_URL + "/hcr-qa1"
OSP = QA_URL + "/osp-qa1"
INTRAX = QA_URL + "/intrax-qa1"
PXR = QA_URL + "/pxr-qa1"
ISR = QA_URL + "/isr-qa1"
III = "app.qa.intraxinc.com/iii-webapp-0.0.1-SNAPSHOT"
CASPER = "cfdevqa.intraxinc.com"
NEMO = "cfdevayusaqa.intraxinc.com"
FAMILYROOM = "cfdevqa.intraxinc.com"
OSP_login = "mvogt@worldstudygroup.comx"
OSP_password = "changeme"
HCR_login = "carrie@mtolympuspark.comx"
HCR_password = "changeme"
CASPER_login = "smcnamara@aupaircare.comx"
NEMO_login = "scarpenter@ayusa.orgx"
INTRAX_login ="ssafyanay@intraxinc.comx"
INTRAX_password = "changeme"
ISR_login = "kagriesemer@gmail.comx"
ISR_password = "changeme"
PXR_login = "zhau_peng87@hotmail.comx"
PXR_password = "changeme"
PXR_id = "970011"

    
        
    
