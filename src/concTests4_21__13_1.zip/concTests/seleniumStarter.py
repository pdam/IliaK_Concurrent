'''
Created on 19.09.2011

@author: User
'''
def startHub():
    pass

def startRC():
    pass

def stopHub():
    pass

def stopRC():
    pass

def startSelenium():
    pass

def stopSelenium():
    pass

if __name__ == '__main__':
    pass